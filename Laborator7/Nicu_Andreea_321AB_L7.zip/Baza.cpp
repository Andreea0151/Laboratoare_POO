#include "Baza.hpp"

Baza :: ~Baza () {}
